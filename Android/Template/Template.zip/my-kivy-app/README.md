# My Kivy App

Ein Beispielprojekt zur Erstellung von Android-Apps mit Python, Kivy und Buildozer.
